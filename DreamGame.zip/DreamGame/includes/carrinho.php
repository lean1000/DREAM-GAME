<div id="carrinho-flutuante" class="carrinho-flutuante" style="display: none;">
    <button id="fechar-carrinho">Fechar</button>
    <div id="itens-carrinho"></div>
    <p>Total: R$ <span id="total-carrinho">0,00</span></p>
    <button id="btn-finalizar">Finalizar Compra</button>
</div>
