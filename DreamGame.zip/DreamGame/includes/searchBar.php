<form action="./busca.php" method="GET" class="search-bar">

    <a href="./busca.php" class="icon-link" title="Abrir filtros">
        <i class="bi bi-funnel"></i>
    </a>

    <input type="text" name="termo" placeholder="Search..." required>

    <button type="submit" class="icon-link" style="background: none; border: none;" title="Buscar">
        <i class="bi bi-search"></i>
    </button>
</form>